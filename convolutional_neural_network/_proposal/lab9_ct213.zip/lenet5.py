from keras import layers, activations
from keras.models import Sequential


def make_lenet5():
    model = Sequential()

    # Todo: implement LeNet-5 model

    return model
